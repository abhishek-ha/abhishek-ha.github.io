function toggleMenu() {
    var element = document.getElementById("sidebar-menu");
    element.classList.toggle("open");
}
