package com.example.web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
